<!DOCTYPE html>
<html>
<head>
 <title></title>
</head>
<body>
 <form action="/courses/add_course" method="post">
  <input type="text" name="title" placeholder="email">
  <input type="text" name="description" placeholder="description">
  <input type="submit" value="Add course">
 </form>
</body>
</html>